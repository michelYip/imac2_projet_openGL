#include "Mesh.hpp"

#include <string> 
#include <vector>
#include <map>
#include <sstream>
#include <glimac/Image.hpp>
#include <exceptions/Unreachable_file.hpp>


std::map<std::string, Mesh> Mesh::_already_created_models = {};


Mesh::Mesh(const std::vector<Vertex3DUV> &vertices, const std::vector<int> &indexes){
	_vertices = vertices;
	_indexes = indexes;

// //VBO
// 	glGenBuffers(1, &_vbo);
//     glBindBuffer(GL_ARRAY_BUFFER, _vbo);
//     glBufferData(
//         GL_ARRAY_BUFFER,
//         _vertices.size() * sizeof(Vertex3DUV),
//         _vertices.data(),
//         GL_STATIC_DRAW
//     );
//     glBindBuffer(GL_ARRAY_BUFFER, 0);

// // IBO
//     // glGenBuffers(1, &_ibo);
//     // // => On bind sur GL_ELEMENT_ARRAY_BUFFER, cible reservée pour les IBOs
//     // glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, _ibo);
//     // // => On remplit l'IBO avec les indices:
//     // glBufferData(GL_ELEMENT_ARRAY_BUFFER, _indexes.size() * sizeof(int), _indexes.data(), GL_STATIC_DRAW);
//     // glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);

// // VAO
//     glGenVertexArrays(1, &_vao);
//     glBindVertexArray(_vao);

//     // glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, _ibo);

//     glEnableVertexAttribArray(POS_ATTRIB_IND);
//     glBindBuffer(GL_ARRAY_BUFFER, _vbo);
//     glVertexAttribPointer(
//         POS_ATTRIB_IND,
//         3,
//         GL_FLOAT,
//         GL_FALSE,
//         sizeof(Vertex3DUV),
//         (const GLvoid*)Vertex3DUV::offset_pos()
//     );
//     glBindBuffer(GL_ARRAY_BUFFER, 0);

//     glEnableVertexAttribArray(NORM_ATTRIB_IND);
//     glBindBuffer(GL_ARRAY_BUFFER, _vbo);
//     glVertexAttribPointer(
//         NORM_ATTRIB_IND,
//         3,
//         GL_FLOAT,
//         GL_FALSE,
//         sizeof(Vertex3DUV),
//         (const GLvoid*)Vertex3DUV::offset_norm()
//     );
//     glBindBuffer(GL_ARRAY_BUFFER, 0);

//     glEnableVertexAttribArray(TEXT_ATTRIB_IND);
//     glBindBuffer(GL_ARRAY_BUFFER, _vbo);
//     glVertexAttribPointer(
//         TEXT_ATTRIB_IND,
//         2,
//         GL_FLOAT,
//         GL_FALSE,
//         sizeof(Vertex3DUV),
//         (const GLvoid*)Vertex3DUV::offset_tex()
//     );
//     glBindBuffer(GL_ARRAY_BUFFER, 0);

//     glBindVertexArray(0);





    glimac::Sphere sphere(1, 32, 16);
    _sphere = sphere;

    glGenBuffers(1, &_vbo);
    glBindBuffer(GL_ARRAY_BUFFER, _vbo);
    glBufferData(
        GL_ARRAY_BUFFER,
        _sphere.getVertexCount() * sizeof(glimac::ShapeVertex),
        _sphere.getDataPointer(),
        GL_STATIC_DRAW
    );
    glBindBuffer(GL_ARRAY_BUFFER, 0);

    glGenVertexArrays(1, &_vao);
    glBindVertexArray(_vao);

    glEnableVertexAttribArray(POS_ATTRIB_IND);
    glBindBuffer(GL_ARRAY_BUFFER, _vbo);
    glVertexAttribPointer(
        POS_ATTRIB_IND,
        3,
        GL_FLOAT,
        GL_FALSE,
        sizeof(glimac::ShapeVertex),
        (const GLvoid*)offsetof(glimac::ShapeVertex, position)
    );
    glBindBuffer(GL_ARRAY_BUFFER, 0);

    glEnableVertexAttribArray(NORM_ATTRIB_IND);
    glBindBuffer(GL_ARRAY_BUFFER, _vbo);
    glVertexAttribPointer(
        NORM_ATTRIB_IND,
        3,
        GL_FLOAT,
        GL_FALSE,
        sizeof(glimac::ShapeVertex),
        (const GLvoid*)offsetof(glimac::ShapeVertex, normal)
    );
    glBindBuffer(GL_ARRAY_BUFFER, 0);

    glEnableVertexAttribArray(TEXT_ATTRIB_IND);
    glBindBuffer(GL_ARRAY_BUFFER, _vbo);
    glVertexAttribPointer(
        TEXT_ATTRIB_IND,
        2,
        GL_FLOAT,
        GL_FALSE,
        sizeof(glimac::ShapeVertex),
        (const GLvoid*)offsetof(glimac::ShapeVertex, texCoords)
    );
    glBindBuffer(GL_ARRAY_BUFFER, 0);

    glBindVertexArray(0);
}


glm::vec3 getvec3(std::string str_line){
	std::istringstream split(str_line); 
	std::vector<std::string> vertice;
	for (std::string each; std::getline(split, each, ' '); vertice.push_back(each.substr(each.find_first_not_of(' '))));
	glm::vec3 point(
		std::stof(vertice.at(1)),
		std::stof(vertice.at(2)),
		std::stof(vertice.at(3))
		);
	return point;
}

glm::vec2 getvec2(std::string str_line){
	std::istringstream split(str_line); 
	std::vector<std::string> vertice;
	for (std::string each; std::getline(split, each, ' '); vertice.push_back(each.substr(each.find_first_not_of(' '))));
	glm::vec2 point(
		std::stof(vertice.at(1)),
		std::stof(vertice.at(2))
		);
	return point;
}



Mesh Mesh::loadObj(const std::string &abs_project_path, const std::string &obj_filename, const std::string &texture_filename){
	//If model already loader by program return it
	// typedef std::map<std::string,Mesh>  mapType;
	// mapType::iterator it = Mesh::_already_created_models.find(obj_filename);
	// if(it != Mesh::_already_created_models.end()){
	// 	return it->second;
	// }

	// //If not load from file
	// std::ifstream objFile;
	// objFile.open(OBJ_FOLDER+obj_filename, std::fstream::in);
	// if(!objFile.is_open())
	// 	throw UNREACHABLE_FILE(OBJ_FOLDER+obj_filename);
	
	std::vector<Vertex3DUV> list_vertice;
	std::vector<int> list_indices;
	// std::vector<glm::vec3> v;
	// std::vector<glm::vec3> vn;
	// std::vector<glm::vec2> vt;
	// std::vector<int> f;
	// int point_count = 0;

	// while(!objFile.eof()){
	// 	char *tmp_line = new char[128];
	// 	objFile.getline(tmp_line,128);
	// 	std::string str_line(tmp_line);

	// 	//remove extra space
	// 	for(int i=str_line.size()-1; i >= 0; i-- )
	//         if(str_line[i]==' '&&str_line[i]==str_line[i-1])
	//             str_line.erase(str_line.begin()+i);
		

	// 	if(str_line.size() != 0 && str_line.compare(0, 2, "v ") == 0){//vertice coords
	// 		v.push_back(getvec3(str_line));
	// 	}else if(str_line.size() != 0 && str_line.compare(0, 2, "vn") == 0){//normals
	// 		vn.push_back(getvec3(str_line));
	// 	}else if(str_line.size() != 0 && str_line.compare(0, 2, "vt") == 0){//textures
	// 		vt.push_back(getvec2(str_line));
	// 	}else if(str_line.size() != 0 && str_line.compare(0, 2, "f ") == 0){//faces
	// 		std::map<std::string, int> point_saver; //To skip creating already existing point

	// 		std::istringstream split(str_line); 
	// 		std::vector<std::string> f;
	// 		for (std::string each; std::getline(split, each, ' '); f.push_back(each));
			
	// 		int nbPoint = f.size();

	// 		//Creating points
	// 		for (int i = 1; i < nbPoint; ++i){
	// 			std::string original_str = f.at(i);
	// 			std::map<std::string, int>::iterator it = point_saver.find(f.at(i));
	// 			if(it == point_saver.end()){	
	// 				int i_v, i_vt, i_vn;
	// 				int pos_slash1, pos_slash2;

	// 				//v
	// 				pos_slash1 = f.at(i).find('/');
	// 				i_v = std::stoi(f.at(i).substr(0,(pos_slash1 == -1) ? f.size() : pos_slash1));
	// 				f.at(i).erase(0,pos_slash1+1);

	// 				//vt
	// 				pos_slash2 = f.at(i).find('/');
	// 				i_vt = (pos_slash2 == 0) ? 0 : std::stoi(f.at(i).substr(0,(pos_slash2 == -1) ? f.size() : pos_slash2));
	// 				f.at(i).erase(0,pos_slash2+1);
					
	// 				//vn
	// 				i_vn = (pos_slash2 == -1) ? 0 : (i < f.size() && f.at(i).size() == 0) ? 0 : std::stoi(f.at(i));
					
	// 				glm::vec3 vertex_v  = (i_v  > 0) ? v.at(i_v-1)   : glm::vec3();
	// 				glm::vec3 vertex_vn = (i_vn > 0) ? vn.at(i_vn-1) : glm::vec3();
	// 				glm::vec2 vertex_vt = (i_vt > 0) ? vt.at(i_vt-1) : glm::vec2();
	// 				list_vertice.push_back(Vertex3DUV(vertex_v,vertex_vn,vertex_vt));
	// 				point_saver[original_str] = point_count;
	// 				list_indices.push_back(point_count++);

	// 			}else{
	// 				list_indices.push_back(point_saver[original_str]);
	// 			}		

	// 			//If too many point for a face we decompose in triangles
	// 			if(nbPoint > 3){
	// 				if(i > 3){
	// 					list_indices.push_back(list_indices.at(list_indices.size()-4));
	// 					list_indices.push_back(list_indices.at(list_indices.size()-3));
	// 				}
	// 			}
	// 		}
	// 	}
	// }
	Mesh mesh(list_vertice, list_indices);
	// mesh.init(list_vertice, list_indices);
	// mesh.loadTexture(abs_project_path, (texture_filename.size() != 0) ? texture_filename : "default.png");
	// _already_created_models[obj_filename] = mesh;
	return mesh;

}


void Mesh::loadTexture(const std::string &abs_project_path, const std::string &filename){
	std::unique_ptr<glimac::Image> image = glimac::loadImage(abs_project_path + TEXTURE_FOLDER + filename);
    if (image == NULL)
        throw UNREACHABLE_FILE(abs_project_path + TEXTURE_FOLDER + filename);

    glGenTextures(1, &_texture);
    glBindTexture(GL_TEXTURE_2D, _texture);
    glTexImage2D(
        GL_TEXTURE_2D,
        0,
        GL_RGBA,
        image->getWidth(),
        image->getHeight(),
        0,
        GL_RGBA,
        GL_FLOAT,
        image->getPixels()
    );
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glBindTexture(GL_TEXTURE_2D, 0);
    std::cout << "Texture [" << abs_project_path << TEXTURE_FOLDER + filename << "] loaded" << std::endl;
}



void Mesh::show(const GLint &uTexture){
	glBindVertexArray(_vao);    
    // glBindTexture(GL_TEXTURE_2D, _texture);
    // glUniform1i(uTexture, 0);
    // glDrawElements(GL_TRIANGLES, _indexes.size(), GL_UNSIGNED_INT, 0);
    // glDrawArrays(GL_TRIANGLES, 0, _vertices.size());
    glDrawArrays(GL_TRIANGLES, 0, _sphere.getVertexCount());
    
    // glBindTexture(GL_TEXTURE_2D, 0);
    glBindVertexArray(0);
}