#ifndef _BONUS_ 
#define _BONUS_

#include "TriggerObject.hpp"

class Bonus : public TriggerObject
{
public:
	Bonus();
	~Bonus();
	
};

#endif