#ifndef _MALUS_ 
#define _MALUS_

#include "TriggerObject.hpp"

class Malus : public TriggerObject
{
public:
	Malus();
	~Malus();
	
};

#endif