#ifndef _PHYSIC_ 
#define _PHYSIC_

class Physic
{
public:
	Physic(){}
	~Physic() = default;
	
};

#endif