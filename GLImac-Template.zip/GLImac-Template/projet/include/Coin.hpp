#ifndef _COIN_ 
#define _COIN_


#include "StaticObject.hpp"

class Coin : public StaticObject
{
public:
	Coin();
	~Coin() = default;
	
};

#endif