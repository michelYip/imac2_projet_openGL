#ifndef _ENEMY_ 
#define _ENEMY_


#include "MovingObject.hpp"

class Enemy : public MovingObject
{
public:
	Enemy();
	~Enemy() = default;
	
};

#endif